This is a website for a Software company . Check the following link --
https://riddhikakundu06.github.io/Software-Website-for-Techy-Software/
